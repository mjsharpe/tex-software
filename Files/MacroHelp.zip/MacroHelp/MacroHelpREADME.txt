Installing MacroHelp for TeXShop:

1. Copy macros_latex.txt to ~/Library/TeXShop/Macros. This file contains the help text.
2. To install the 'Macro Help' macro in TeXShop's Macros menu.
(a) Open TeXShop's Macros menu and select Open Macro Editor...
(b) Open TeXShop's Macros menu again and select the newly revealed item 'Add  macros from file...'
(c) navigate to MacroHelp.plist, and open it. This will copy the macro into your Macros menu. Move it somewhere near the top for easy access.
(d) Press the Save button to finish this installation.

Alternatively, you might like to try installing it from the application MacroCopier at:

http://dl.dropboxusercontent.com/u/3825336/TeX/index.html
