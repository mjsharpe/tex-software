This is macro for TeXShop's Macro Menu, allowing you to bring up a list of labels containing specified text, and move to the chosen label.

To install, choose Macros/Open Macro Editor... (in the TeXShop main menus) and then from the Macros menu, choose Add Macros from File. This brings up a file selector with which you may select GotoLabel.plist. This instaall the macro in the Macro Menu, where you may move it to any convenient position, and, if you wish, give it a hot key.

This provides an alternative to adding an item to TeXShop's tags by inserting a line

%:tag_name

in the source. With a lengthy document with many labels, it seems advantageous to be able to filter the list of labels.