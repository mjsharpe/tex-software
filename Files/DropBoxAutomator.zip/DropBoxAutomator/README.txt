Instructions for creating an Automator Application that does three things:
  1. copy dropped/dragged files into your Dropbox/Public/TeX/Files folder;
  2. create an empty .txt file for each new .dmg/.zip file;
  3. open each of the newly created .txt files using the bbedit command line.
  
Note that the script must be customized to your setup. You must have installed the DropboxIndex package for this to work. If you don't have bbedit, install the free TextWrangler, install its command line tools and use them instead.

To create the Automator Application:
  1. Open Automator---it's in /Applications;
  2. choose to make an Application;
  3. from the search box, type 'shell' (without the quotes) and drag Run Shell Strip to the panel on the right---this is the only action needed;
  4. select /usr/bin/python as the shell and select Pass input as arguments;
  5. copy the contents of the edited pythonScriptForAutomator.txt into the body of the action, overwriting whatever was initially there;
  6. choose Save and give it a name meaningful to you.
  
This generates an application that expects files to be dropped to initiate the script. I find it most convenient to use it via a toolbar icon---just drag the applications icon to the toolbar of any finder window. Then you can drag files from any Finder window to that icon to run the script. Note that after you edit the corresponding .txt files and save them you must run mkidx again to refresh the index file. For this, it is useful to have a shell script with contents

#!/bin/sh
cd /Volumes/MyRAID/msharpe/Dropbox/Public/TeX/Files
~/bin/mkidx

(named something like updindx, located in your $PATH and made executable) that you can call after the last edit.