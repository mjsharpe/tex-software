This is an AppleScript macro for TeXShop's Macros Menu. I use this to post-process output from a tex file. The macro parses your front tex document and gathers all lines that begin with

% CMD=

saving what comes after this, ending with the next line-break. The resulting list of commands is joined with " && " and prepended with "cd <directory of front document> && ", then used as the object for "do shell script ".

Example:

I have a tex driver file for fontinst that begins

% !TEX TS-program = tex
% CMD=apply /usr/texbin/vptovf ntx*mia.vpl
% CMD=/bin/cp -fp ntx*mia.tfm ~/tmfv/fonts/tfm/public/newtx
% CMD=/bin/cp -fp ntx*mia.vf ~/tmfv/fonts/vf/public/newtx
\input fontinst.sty

After typsetting the file, which generates ntxmia.vpl and ntxbmia.vpl, I run the macro, producing the corresponding tfm and vf fonts, then copying them to a location where tex will find them for testing. (I set up ~/tmfv as a symlink currently pointing to ~/Library/texlive/2014/texmf-var.)

This processing could have been handled by a makefile, but I find it more transparent and easier to modify when I keep the processing commands with the driver file.